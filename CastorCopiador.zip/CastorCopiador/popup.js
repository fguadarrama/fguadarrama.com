/* ────────────────────────────────────────────────────────
   Copiador de Laboratorios — popup.js
   Chrome Extension (Manifest V3)
   Scrapes the INCMNSZ lab-results portal and formats
   values as clean, clinical plain-text.
   ──────────────────────────────────────────────────────── */

const runBtn = document.getElementById("run");
const copyBtn = document.getElementById("copy");
const out = document.getElementById("out");
const statusEl = document.getElementById("status");
const highlightCb = document.getElementById("highlight");
const onlyAbnCb = document.getElementById("onlyAbn");

/* ── Status helpers ─────────────────────────────────── */
function setStatus(msg, type = "") {
  statusEl.textContent = msg || "";
  statusEl.className = "status" + (type ? ` ${type}` : "");
}

/* ── Copy button ────────────────────────────────────── */
copyBtn.addEventListener("click", async () => {
  const text = out.value || "";
  if (!text) { setStatus("Nada que copiar.", "error"); return; }
  try {
    await navigator.clipboard.writeText(text);
    setStatus("✓ Copiado al portapapeles.", "success");
  } catch {
    setStatus("No se pudo copiar. Copia manualmente.", "error");
  }
});

/* ── Run button ─────────────────────────────────────── */
runBtn.addEventListener("click", async () => {
  setStatus("");
  out.value = "";

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) { setStatus("No se detectó pestaña activa.", "error"); return; }

  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: scrapeAndFormat,
      args: [{ highlight: highlightCb.checked, onlyAbnormal: onlyAbnCb.checked }]
    });

    out.value = result?.text || "";
    if (result?.warning) {
      setStatus(result.warning, "error");
    } else {
      setStatus("✓ Listo — texto generado.", "success");
    }
  } catch (err) {
    setStatus("Error: abre la pantalla de resultados y reintenta.", "error");
    console.error(err);
  }
});

/* ────────────────────────────────────────────────────────
   INJECTED FUNCTION — runs inside the active tab
   ──────────────────────────────────────────────────────── */
function scrapeAndFormat(opts) {

  /* ── Utilities ──────────────────────────────────────── */
  const norm = (s) => (s || "").replace(/\s+/g, " ").trim();

  // Strip diacritics/accents for matching
  function stripAccents(s) {
    return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  }

  function toNum(s) {
    if (!s) return null;
    const m = String(s).trim().replace(",", "").match(/-?\d+(\.\d+)?/);
    return m ? Number(m[0]) : null;
  }

  function parseRange(s) {
    if (!s) return null;
    const m = String(s).replace(",", "").match(/(-?\d+(\.\d+)?)\s*-\s*(-?\d+(\.\d+)?)/);
    if (!m) return null;
    const low = Number(m[1]), high = Number(m[3]);
    return (Number.isFinite(low) && Number.isFinite(high)) ? { low, high } : null;
  }

  /* ── Abbreviation map ───────────────────────────────── */
  const ABBR = [
    /* Biometría hemática — order matters: longer prefixes first */
    ["HEMOGLOBINA CORPUSCULAR", "HCM"],
    ["HEMOGLOBINA GLUCOSILADA", "HbA1c"],
    ["HEMOGLOBINA", "Hb"],
    ["HEMATOCRITO", "Hto"],
    ["ERITROCITOS", "Erit"],
    ["LEUCOCITOS", "Leu"],
    ["PLAQUETAS", "Plt"],
    ["NEUTROFILOS", "Neu"],
    ["LINFOCITOS", "Linf"],
    ["MONOCITOS", "Mono"],
    ["EOSINOFILOS", "Eos"],
    ["BASOFILOS", "Baso"],
    ["BANDAS", "Bandas"],
    ["VOLUMEN CORPUSCULAR MEDIO", "VCM"],
    ["VCM", "VCM"],
    ["HCM", "HCM"],
    ["CONCENTRACION MEDIA DE HEMOGLOBINA", "CMHB"],
    ["CONCENTRACION MEDIA", "CMHB"],
    ["CONCENTRACION", "CMHB"],
    ["CMHB", "CMHB"],
    ["AMPLITUD DE DISTRIBUCION", "RDW"],
    ["ANCHO DE DISTRIBUCION", "RDW"],
    ["RDW", "RDW"],
    ["VOLUMEN PLAQUETARIO MEDIO", "VPM"],
    ["VPM", "VPM"],
    ["RETICULOCITOS", "Retic"],
    ["METAMIELOCITOS", "Metamiel"],
    ["MIELOCITOS", "Mieloc"],
    ["PROMIELOCITOS", "Promiel"],
    ["BLASTOS", "Blastos"],

    /* Química sanguínea */
    ["GLUCOSA", "Glu"],
    ["CREATININA", "Cr"],
    ["UREA", "Urea"],
    ["NITROGENO UREICO", "BUN"],
    ["NITROGENO", "BUN"],
    ["ACIDO URICO", "AU"],
    ["COLESTEROL TOTAL", "Col"],
    ["COLESTEROL", "Col"],
    ["TRIGLICERIDOS", "Tg"],
    ["HDL", "HDL"],
    ["LDL", "LDL"],
    ["VLDL", "VLDL"],
    ["PROTEINAS TOTALES", "Proteínas totales"],
    ["PROTEINAS", "Proteínas totales"],
    ["ALBUMINA", "Alb"],
    ["ALBÚMINA", "Alb"],
    ["GLOBULINA", "Glob"],
    ["RELACION A/G", "Rel A/G"],
    ["RELACION BD/BI", "Rel BD/BI"],
    ["BILIRRUBINA TOTAL", "BT"],
    ["BILIRRUBINA DIRECTA", "BD"],
    ["BILIRRUBINA INDIRECTA", "BI"],
    ["BILIRRUBINA", "Bil"],
    ["TRANSAMINASA GLUTAMICO OXALACETICA", "TGO"],
    ["ASPARTATO AMINOTRANSFERASA", "AST"],
    ["TGO", "TGO"],
    ["AST", "AST"],
    ["TRANSAMINASA GLUTAMICO PIRUVICA", "TGP"],
    ["ALANINO AMINOTRANSFERASA", "ALT"],
    ["TGP", "TGP"],
    ["ALT", "ALT"],
    ["FOSFATASA ALCALINA", "FAlc"],
    ["DESHIDROGENASA LACTICA", "DHL"],
    ["DHL", "DHL"],
    ["LDH", "LDH"],
    ["GAMMA GLUTAMIL", "GGT"],
    ["GAMMAGLUTAMIL", "GGT"],
    ["GGT", "GGT"],
    ["AMILASA", "Amil"],
    ["LIPASA", "Lip"],

    /* Electrolitos */
    ["SODIO", "Na"],
    ["POTASIO", "K"],
    ["CLORO", "Cl"],
    ["CALCIO", "Ca"],
    ["MAGNESIO", "Mg"],
    ["FOSFORO", "P"],
    ["DIOXIDO DE CARBONO", "CO₂"],

    /* Coagulación */
    ["TIEMPO DE PROTROMBINA", "TP"],
    ["TIEMPO DE TROMBOPLASTINA", "TTP"],
    ["INR", "INR"],
    ["TTPA", "TTPa"],
    ["FIBRINOGENO", "Fib"],
    ["DIMERO D", "DD"],

    /* Gasometría */
    ["PH", "pH"],
    ["PCO2", "pCO₂"],
    ["PO2", "pO₂"],
    ["BICARBONATO", "HCO₃"],
    ["EXCESO DE BASE", "EB"],
    ["SATURACION", "SatO₂"],
    ["LACTATO", "Lac"],

    /* Inmunología & otros */
    ["PROTEINA C REACTIVA", "PCR"],
    ["PCR", "PCR"],
    ["VELOCIDAD DE SEDIMENTACION", "VSG"],
    ["VSG", "VSG"],
    ["PROCALCITONINA", "PCT"],
    ["FERRITINA", "Ferr"],
    ["HIERRO SERICO", "Fe"],
    ["TRANSFERRINA", "Transf"],
    ["VITAMINA", "Vit"],
    ["HBA1C", "HbA1c"],
    ["ANTIGENO PROSTATICO", "PSA"],
    ["PSA", "PSA"],

    /* Pruebas tiroideas */
    ["TIROGLOBULINA", "Tg"],
    ["CAPTACION DE TIROXINA", "TU"],
    ["CAPTACION", "TU"],
    ["HORMONA ESTIMULANTE DE TIROIDES", "TSH"],
    ["HORMONA ESTIMULANTE", "TSH"],
    ["TSH", "TSH"],
    ["TIROXINA LIBRE", "T4L"],
    ["TRIYODOTIRONINA TOTAL", "T3"],
    ["TRIYODOTIRONINA", "T3"],
    ["TIROXINA TOTAL", "T4"],
    ["TIROXINA", "T4"],
    ["T4 LIBRE", "T4L"],
    ["T3 TOTAL", "T3"],
    ["T4 TOTAL", "T4"],
    ["T3", "T3"],
    ["T4", "T4"],

    /* EGO / Uroanálisis */
    ["DENSIDAD", "Densidad"],
    ["ASPECTO", "Aspecto"],
    ["COLOR", "Color"],
    ["NITRITOS", "Nitritos"],
    ["SANGRE", "Sangre"],
    ["CUERPOS", "Cuerpos cetónicos"],
    ["UROBILINOGENO", "Urobilinógeno"],
    ["MICROALBUMINA", "mAlb"],
    ["RELACION ALBUMINA", "Rel Alb/Cr"],
  ];

  function abbreviate(testName) {
    const up = stripAccents(norm(testName)).toUpperCase();
    for (const [key, val] of ABBR) {
      if (up.startsWith(key)) return val;
    }
    // Fallback: capitalize first word
    const first = norm(testName).split(" ")[0];
    return first.charAt(0).toUpperCase() + first.slice(1).toLowerCase();
  }

  /* ── Section heading maps ───────────────────────────── */
  // Top-level area (blue rows) → canonical heading
  function areaToHeading(raw) {
    const t = stripAccents((raw || "").toUpperCase());
    if (t.includes("HEMATO")) return "Biometría hemática";
    if (t.includes("QUIMICA")) return "Química sanguínea";
    if (t.includes("UROANALISIS") || t.includes("URO")) return "EGO";
    if (t.includes("INMUNO")) return "Inmunología";
    if (t.includes("COAG")) return "Coagulación";
    if (t.includes("GASOMETRIA")) return "Gasometría";
    if (t.includes("SEROLOGIA")) return "Serología";
    if (t.includes("HORMON") || t.includes("ENDOCRIN")) return "Hormonas";
    return norm(raw);
  }

  // Subsection (yellow/white rows) → canonical heading, or null = use parent
  function subsectionToHeading(raw, parentHeading) {
    const t = stripAccents((raw || "").toUpperCase());
    // BH subsections → stay under parent
    if (t.includes("CITOLOGIA") || t.includes("DIFERENCIAL"))
      return parentHeading || "Biometría hemática";
    // QS subsections → stay under parent
    if (t.includes("QUIMICA SANGUINEA") || t.includes("FUNCIONAMIENTO HEPAT")
      || t.includes("PRUEBAS DE FUNCION") || t.includes("PERFIL"))
      return parentHeading || "Química sanguínea";
    // Electrolitos
    if (t.includes("ELECTROL"))
      return "Electrolitos séricos";
    // EGO subsections
    if (t.includes("EXAMEN GENERAL") || t.includes("EGO") || t.includes("SEDIMENTO"))
      return "EGO";
    // Urinary chemistry
    if (t.includes("QUIMICA URIN") || t.includes("ALBUMINA/CREATININA")
      || t.includes("RELACION ALBUM"))
      return "Química urinaria";
    // Coagulación
    if (t.includes("COAG") || t.includes("TIEMPOS"))
      return "Coagulación";
    // Pruebas tiroideas
    if (t.includes("FUNCION TIROIDEA") || t.includes("TIROIDEA") || t.includes("TIROIDES"))
      return "Pruebas tiroideas";
    // Gasometría
    if (t.includes("GASOMETRIA"))
      return "Gasometría";
    // Fall back to parent heading if set
    return parentHeading || norm(raw);
  }

  /* ── Find the results table ─────────────────────────── */
  function findResultsTable() {
    // Prefer the known container
    const container = document.getElementById("div-results-content")
      || document.getElementById("div-results");
    if (container) {
      const tbl = container.querySelector("table");
      if (tbl) return tbl;
    }
    // Fallback: scan all tables for the header signature
    for (const tbl of document.querySelectorAll("table")) {
      const hdr = norm(
        (tbl.querySelector("thead")?.innerText || tbl.querySelector("tr")?.innerText || "")
      ).toLowerCase();
      if (hdr.includes("prueba") && hdr.includes("resultado") && hdr.includes("referencia")) {
        return tbl;
      }
    }
    return null;
  }

  /* ── Row classification ─────────────────────────────── */
  function classifyRow(tr) {
    const tds = Array.from(tr.querySelectorAll("td"));
    if (tds.length === 0) return { type: "skip" };
    // Check for section/subsection rows: 1 cell with large colspan
    if (tds.length === 1 || (tds.length <= 2 && tds[0].colSpan >= 4) || (tds.length >= 1 && tds[0].colSpan >= 6)) {
      // Distinguish area (blue bg) vs subsection (other) by background color
      const bg = window.getComputedStyle(tr).backgroundColor;
      // Blue backgrounds (like rgb(88,124,186)) → area
      const m = bg.match(/rgb\((\d+),\s*(\d+),\s*(\d+)/);
      const isBlue = m && parseInt(m[3]) > parseInt(m[1]) && parseInt(m[2]) < 180;
      return { type: isBlue ? "area" : "subsection", label: norm(tr.innerText) };
    }
    return { type: "data" };
  }

  /* ── Abnormality detection ──────────────────────────── */
  function pathologyFromRow(tr) {
    // Check the last relevant td for glyphicon arrows
    const tds = Array.from(tr.querySelectorAll("td"));
    for (const td of tds) {
      if (td.querySelector(".glyphicon-arrow-up")) return "alto";
      if (td.querySelector(".glyphicon-arrow-down")) return "bajo";
    }
    return null;
  }

  function numericAbnormal(resultRaw, refRaw) {
    const v = toNum(resultRaw);
    const rr = parseRange(refRaw);
    if (v === null || !rr) return null;
    if (v < rr.low) return "bajo";
    if (v > rr.high) return "alto";
    return null;
  }

  /* ── Inject highlight CSS ───────────────────────────── */
  if (opts?.highlight) {
    const id = "copiador-lab-style";
    if (!document.getElementById(id)) {
      const st = document.createElement("style");
      st.id = id;
      st.textContent = `
        .cop-abn     { background: rgba(220,38,38,0.06) !important; }
        .cop-high td { border-left: 4px solid rgba(234,88,12,0.9) !important; }
        .cop-low  td { border-left: 4px solid rgba(37,99,235,0.9) !important; }
      `;
      document.head.appendChild(st);
    }
  }

  /* ── Main scraping ──────────────────────────────────── */
  const tbl = findResultsTable();
  if (!tbl) {
    return { text: "", warning: "No se encontró la tabla de resultados. Asegúrate de tener resultados visibles." };
  }

  // Gather all rows from potentially multiple <tbody> elements
  const allRows = Array.from(tbl.querySelectorAll("tbody tr, tr"));
  // Deduplicate (some rows might appear if there's no tbody)
  const seen = new Set();
  const rows = [];
  for (const r of allRows) {
    if (!seen.has(r)) { seen.add(r); rows.push(r); }
  }

  const bySection = new Map();
  let parentArea = null;   // top-level area (blue row)
  let currentSection = null; // resolved heading for data rows

  function ensureSection(sec) {
    if (!bySection.has(sec)) bySection.set(sec, []);
  }

  // Skip tests that are just metadata/noise
  const SKIP = /^(bibliografia|suma diferencial|observacion|nota|metodo|agregados|cilindros|cristales|filamento|levaduras|bacterias|celulas escamosas|celulas redondas)/i;

  for (const tr of rows) {
    // Clear previous highlights
    tr.classList.remove("cop-abn", "cop-high", "cop-low");

    const rowInfo = classifyRow(tr);

    if (rowInfo.type === "area") {
      parentArea = areaToHeading(rowInfo.label);
      currentSection = parentArea;
      ensureSection(currentSection);
      continue;
    }

    if (rowInfo.type === "subsection") {
      currentSection = subsectionToHeading(rowInfo.label, parentArea);
      ensureSection(currentSection);
      continue;
    }

    if (rowInfo.type === "skip") continue;

    const tds = Array.from(tr.querySelectorAll("td"));
    if (tds.length < 5) continue;  // Not a data row

    // Detect column indices dynamically
    // The first cell typically has the checkbox + test name
    const testCell = tds[0];
    // Extract text, stripping any checkbox artifacts
    const rawTestText = norm(testCell.innerText);
    const testName = rawTestText;

    if (!testName || SKIP.test(testName)) continue;

    // Find the result cell — it's typically the one with class "tooltipstered"
    // or the 3rd cell (index 2). We'll try both approaches.
    let resultRaw = "";
    let refRaw = "";
    let unit = "";

    // Strategy: look for the "tooltipstered" td for the result
    const tooltipTd = tr.querySelector("td.tooltipstered");
    if (tooltipTd) {
      const tooltipIdx = tds.indexOf(tooltipTd);
      resultRaw = norm(tooltipTd.innerText);
      refRaw = norm(tds[tooltipIdx + 1]?.innerText || "");
      unit = norm(tds[tooltipIdx + 2]?.innerText || "");
    } else {
      // Fallback: assume fixed positions
      // td[0]=test, td[1]=status, td[2]=result, td[3]=ref, td[4]=unit
      resultRaw = norm(tds[2]?.innerText || "");
      refRaw = norm(tds[3]?.innerText || "");
      unit = norm(tds[4]?.innerText || "");
    }

    // Skip pending results
    if (!resultRaw || /pendiente/i.test(resultRaw)) continue;
    // Skip non-numeric text results that look like status labels
    if (/^(impreso|validado|parcial)$/i.test(resultRaw)) {
      // The "status" column was picked up as result. Shift columns.
      resultRaw = norm(tds[3]?.innerText || "");
      refRaw = norm(tds[4]?.innerText || "");
      unit = norm(tds[5]?.innerText || "");
      if (!resultRaw || /pendiente/i.test(resultRaw)) continue;
    }

    if (!currentSection) {
      currentSection = "Resultados";
      ensureSection(currentSection);
    }

    // Detect abnormality
    let abn = pathologyFromRow(tr);
    if (!abn) abn = numericAbnormal(resultRaw, refRaw);

    // Highlight on page
    if (opts?.highlight && abn) {
      tr.classList.add("cop-abn");
      tr.classList.add(abn === "alto" ? "cop-high" : "cop-low");
    }

    // Filter if only-abnormal mode
    if (opts?.onlyAbnormal && !abn) continue;

    bySection.get(currentSection).push({
      abbr: abbreviate(testName),
      rawName: testName,
      result: resultRaw,
      unit,
      abn
    });
  }

  /* ── Post-processing filters (user customizations) ─── */

  // Remove entire sections the user doesn't want
  bySection.delete("Química urinaria");

  // ─── BH filters ───
  if (bySection.has("Biometría hemática")) {
    let bh = bySection.get("Biometría hemática");

    // 1. Skip differential % values — keep only absolute counts / non-%
    //    Exception: Hto is in % but should be kept
    bh = bh.filter(x => {
      if (x.unit && x.unit.trim() === "%" && !/^(hto|hematocrito)/i.test(x.rawName)) return false;
      return true;
    });

    // 2. Remove VPM and RDW entirely
    bh = bh.filter(x => !/^(VPM|RDW)$/i.test(x.abbr));

    // 3. Skip Metamiel, Mieloc, Promiel, Blastos ONLY if all four are zero
    const immatureNames = ["METAMIEL", "MIELOC", "PROMIEL", "BLASTOS"];
    const immatureItems = bh.filter(x => immatureNames.includes(x.abbr.toUpperCase()));
    const allZero = immatureItems.length > 0 && immatureItems.every(x => {
      const v = parseFloat(String(x.result).replace(",", ""));
      return v === 0;
    });
    if (allZero) {
      bh = bh.filter(x => !immatureNames.includes(x.abbr.toUpperCase()));
    }

    // 4. Hide any item whose result is zero
    bh = bh.filter(x => {
      const v = parseFloat(String(x.result).replace(",", ""));
      return isNaN(v) || v !== 0;
    });

    // 5. Enforce order: Hb, Hto, Leu, Neu, Plt first, then the rest
    const PRIORITY = ["HB", "HTO", "LEU", "NEU", "PLT"];
    const top = [];
    const rest = [];
    for (const item of bh) {
      if (PRIORITY.includes(item.abbr.toUpperCase())) {
        top.push(item);
      } else {
        rest.push(item);
      }
    }
    // Sort top items to match PRIORITY order
    top.sort((a, b) => PRIORITY.indexOf(a.abbr.toUpperCase()) - PRIORITY.indexOf(b.abbr.toUpperCase()));
    bh = [...top, ...rest];

    bySection.set("Biometría hemática", bh);
  }

  // ─── QS filters ───
  if (bySection.has("Química sanguínea")) {
    let qs = bySection.get("Química sanguínea");
    // Remove Rel A/G, Rel BD/BI, and bare "Relación" entries
    qs = qs.filter(x => !/^rel(\s|a)/i.test(x.abbr) && !/^relaci/i.test(x.abbr));
    bySection.set("Química sanguínea", qs);
  }

  // ─── ES filters ───
  if (bySection.has("Electrolitos séricos")) {
    let es = bySection.get("Electrolitos séricos");
    // Remove CO₂
    es = es.filter(x => !/^CO/i.test(x.abbr));
    bySection.set("Electrolitos séricos", es);
  }

  // ─── EGO filters ───
  if (bySection.has("EGO")) {
    let ego = bySection.get("EGO");
    // Whitelist: only keep Densidad, Proteínas, Cuerpos cetónicos, Nitritos,
    //            Eritrocitos cel/HPF, Células cel/HPF
    ego = ego.filter(x => {
      const n = x.rawName.toUpperCase();
      if (n.includes("DENSIDAD")) return true;
      if (n.includes("PROTEINA")) return true;
      if (n.includes("CUERPOS")) return true;
      if (n.includes("NITRITO")) return true;
      if (n.includes("ERITROCITO") && x.unit && x.unit.includes("cel/HPF")) return true;
      if (n.includes("CELULA") && x.unit && x.unit.includes("cel/HPF")) return true;
      // Also match abbreviated names
      if (x.abbr === "Densidad") return true;
      if (/^(Erit|Células)$/i.test(x.abbr) && x.unit && x.unit.includes("cel/HPF")) return true;
      return false;
    });
    bySection.set("EGO", ego);
  }

  /* ── Output formatting ──────────────────────────────── */
  const ORDER = [
    "Biometría hemática",
    "Química sanguínea",
    "Electrolitos séricos",
    "Coagulación",
    "Pruebas tiroideas",
    "EGO",
    "Inmunología",
    "Gasometría",
    "Hormonas",
    "Serología",
    "Resultados"
  ];

  // Build ordered section list
  const sectionOrder = [];
  for (const s of ORDER) {
    if (bySection.has(s) && bySection.get(s).length) sectionOrder.push(s);
  }
  for (const s of bySection.keys()) {
    if (!sectionOrder.includes(s) && bySection.get(s).length) sectionOrder.push(s);
  }

  // Units to strip from output (common, implied by section context)
  const STRIP_UNITS = /^(X10[∧^]\d+\/[µu]L|mmol\/L|mg\/dL)$/i;

  // Format numeric result: max 1 decimal, drop trailing .0
  function formatNumber(s) {
    // Match a number (possibly negative) in the string
    const m = String(s).match(/^(-?\d+)\.(\d+)$/);
    if (!m) return s; // not a plain decimal number, return as-is
    const intPart = m[1];
    const decPart = m[2];
    if (decPart === "0" || decPart === "00" || /^0+$/.test(decPart)) {
      return intPart; // drop .0
    }
    return `${intPart}.${decPart.charAt(0)}`; // keep only first decimal
  }

  function formatItem(x) {
    const val = formatNumber(x.result);
    let line = `${x.abbr} ${val}`;
    // Append unit only if it's NOT in the strip list
    if (x.unit && !STRIP_UNITS.test(x.unit.trim())) {
      line += ` ${x.unit}`;
    }
    if (x.abn === "alto") line += " (↑)";
    if (x.abn === "bajo") line += " (↓)";
    return line;
  }

  const lines = [];
  for (const sec of sectionOrder) {
    const items = bySection.get(sec);
    if (!items?.length) continue;
    lines.push(sec);
    lines.push(items.map(formatItem).join(", "));
    lines.push("");
  }

  const text = lines.join("\n").trim() + "\n";
  return { text, warning: "" };
}
